/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpr2tp02;
import javax.swing.SwingUtilities;
/**
 *
 * @author aluno
 */
public class Lpr2tp02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> new Demogridlayout().setVisible(true));
    }
    
}    

